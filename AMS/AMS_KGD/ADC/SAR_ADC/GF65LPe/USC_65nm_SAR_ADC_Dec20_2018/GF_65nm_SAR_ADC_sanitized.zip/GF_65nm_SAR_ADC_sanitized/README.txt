## Permission must be obtained from the USC POSH project Maintainer to access 

## the original, unsanitized files. Please contact @USCPOSH or unglaub@usc.edu 

## for the necessary permissions.

## Private filename: [USC_65nm_SAR_ADC_Dec20_2018.tar.gz]