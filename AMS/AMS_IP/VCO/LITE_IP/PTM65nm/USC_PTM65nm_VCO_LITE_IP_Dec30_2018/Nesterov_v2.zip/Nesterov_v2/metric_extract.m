function [f0,Delta_f,f0_array]=metric_extract(inputs)
%extract desired metrics from LTspice simulations


f0_array=zeros(1,length(inputs{12}));
%parallelized loop to compute tuning range
parfor i=1:length(inputs{12})
    [f0_array(i)]=freq_extract(inputs,i);
end

%Metric #1: nominal frequency (for a constant set of Wp,Wn,Wnb values at Vctrl=0)
if inputs{13}==1 %solitary VCO
    f0=f0_array(1);
elseif inputs{13}==2 %PLL
    f0=f0_array(8); %(this is actually fc)
end
%Metric #2: tuning range (for a constant set of Wp,Wn,Wnb values)
Delta_f=range(f0_array); %determine value of SECOND metric (tuning range)


end


