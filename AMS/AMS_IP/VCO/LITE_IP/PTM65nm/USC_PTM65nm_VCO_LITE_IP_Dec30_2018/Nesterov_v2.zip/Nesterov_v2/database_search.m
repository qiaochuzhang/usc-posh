function [candidates]=database_search(metrics)
%Sort and search database according to weighted metrics (f0) and distance
%bound (eps). This has the potential to become significantly more
%sophisticated in the future.

% clear all; clc;
% load metrics.mat;
% schem='VCO9';
    
disp('Searching database for compatible solutions...');

%{
FT = 365; %desired output frequency
eps = 5; %test case
eps = eps/100; %convert to number
%}        

FT  = metrics{1}; %target frequency (MHz)
SLB = metrics{2}; %state level bounds (V)
DCB = metrics{3}; %duty cycle bounds
eps = metrics{4}(1); %percent distance of target frequency to search in database (%)
tol = metrics{4}(2); %percent tolerance for gradient/steepest descent (%)
nit = metrics{4}(3); %number of iterations to scan for convergence to incorrect minimum
DF  = metrics{8}; %target tuning range (MHz)
sheet = metrics{9}; %circuit type ('1'=VCO9,'2'=PLL1)

%load up the database for searching
% DB = importdata(['database_',schem,'.mat']);
%=============================WVU EDIT====================================%
if sheet==1 %solitary VCO optimization
    DB_filename='database_VCO9.mat'; 
    col_ind=4;
elseif sheet==2 %VCO optimization for PLL
    DB_filename='database_PLL1.mat';
    col_ind=11;
end
DB=importdata(DB_filename);
datadist=zeros(size(DB,1),1); %preallocate
for i=1:size(DB,1)
    datadist(i)=distance(DB(i,col_ind),DB(i,end),FT,DF);
end

if min(datadist)<=eps    
    %solution found in database (meeting user tolerance)!!
    sol_ind=find(datadist==min(datadist));
    candidates=DB(sol_ind(1),:);    
else
    %for Nesterov, must filter out all designs which fall outside the
    %following range: 1.8 < Wp/Wn < 2.8
    DBR=[]; %DataBase Ratio matrix (consider only solutions satisfying inequality)
    dist_CV=[]; %distance Column Vector for filtered database matrix
    for i=1:size(DB,1)
        if DB(i,2)/DB(i,1)>1.8 && DB(i,2)/DB(i,1)<2.8 %apply width condition
            DBR=[DBR;DB(i,:)]; %append to new matrix (to be sorted below)
            %compute distance for approved design
            dist_CV=[dist_CV;distance(DB(i,col_ind),DB(i,end),FT,DF)];
        end    
    end
    %sort distances and extract index mapping for DBR candidates
    [~,ind]=sort(dist_CV);
    temp=DBR(ind,:);
    candidates=temp(1:10,:); %top ten closest designs are extracted for output
end
%=========================================================================%

%sort database according to prioritized metric
% m_ind=1; %metric index (will eventually be determined from header and priorities)
% SDB=sortrows(DB,m_ind);
% SDB=DB;

end