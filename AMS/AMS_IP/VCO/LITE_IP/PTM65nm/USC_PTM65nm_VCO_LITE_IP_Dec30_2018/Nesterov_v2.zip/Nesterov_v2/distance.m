function [dist] = distance(f,Df,f_s,Df_s)
dist=((f - f_s).^2)+((Df - Df_s)*10^(-2)).^2;
end