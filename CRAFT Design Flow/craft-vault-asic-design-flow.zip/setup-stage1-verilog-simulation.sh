#!/bin/bash

# custom script for cadence-nc-sim
undefined

