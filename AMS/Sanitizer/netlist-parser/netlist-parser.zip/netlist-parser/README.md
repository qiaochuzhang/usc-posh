# NOTE

The Netlist Parse is under development and not ready for productin use.


# Development

```bash
git clone

cd netlist-parser

make
```

# Contributing

## Report Issues

## Submit Pull Requests


# TODOS

1. Add steps to deploy to PyPi when this repo is made public.

1. Currently, Netlist Parser does not support all netlist specification.
    * Spice simluation language is not supported.
    * The `check` control statement is not *fully* supported.
    * The `ic` control statement is not *fully* supported.
    * The `info` control statement is not *fully* supported.
    * The `options` control statement is not *fully* supported.
    * The `paramset` control statement is not *fully* supported.
    * The `statistics` block is not *fully* supported.
    * The `nodeset` control statement is *not* supported.

