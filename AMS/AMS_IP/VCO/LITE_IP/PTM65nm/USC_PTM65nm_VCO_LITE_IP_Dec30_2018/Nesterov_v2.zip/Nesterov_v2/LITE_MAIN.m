% Copyright [2019]
% 
% Licensed under the Apache License, Version 2.0 (the "License");
% you may not use this file except in compliance with the License.
% You may obtain a copy of the License at
% 
%     http://www.apache.org/licenses/LICENSE-2.0
% 
% Unless required by applicable law or agreed to in writing, software
% distributed under the License is distributed on an "AS IS" BASIS,
% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
% See the License for the specific language governing permissions and
% limitations under the License.

% User input script
clear all; clc; clf; close all;

%orders of magnitude (using reciprocal convention, which treats prefixes as units)
femto=1e15; pico=1e12; nano=1e9; micro=1e6; milli=1e3; centi=1e2; 
kilo=1e-3; Mega=1e-6; Giga=1e-9; Tera=1e-12; Peta=1e-15;

% Load user specs and begin optimization protocol -------------------------%

disp(['|=====================================================================|']);
disp(['|============================VCO OPTIMIZER============================|']);
disp(['|=====================================================================|']);

disp(' ');
disp(['Select which program you are using:']);
disp(['1: MATLAB']);
disp(['2: GNU Octave']);
program_switch=input(['Program: ']);

if program_switch==2 %require Octave compatibility
    warning off;
    pkg load io; %spreadsheet I/O package
    %pkg load parallel; %parallel package (does not work if using Windows)
end

disp(' ');
filename = 'LITE_header.xlsx';
disp(['Select which circuit to optimize:']);
disp(['1: 9-stage single-ended VCO using PTM65']);
% disp(['2: Single-ended PLL using PTM65']);
% disp(['3: 3-stage differential VCO using PTM65']);
% disp(['4: 4-stage differential VCO using PTM65']);
% disp(['5: 5-stage differential VCO using PTM65']);

sheet = input(['Circuit: ']);
disp([' ']);
fprintf(['Read in user-specs...']);
[~,~,user_specs]=xlsread(filename,1);

%string inputs
folder   = user_specs{2,2};
schem    = user_specs{3,2};
probe    = user_specs{4,2};
exe_path = user_specs{5,2};

%user inputs
FT   = user_specs{10,2};
DF   = user_specs{11,2};
eps  = user_specs{12,2};
tol  = user_specs{13,2};
nit  = user_specs{14,2};
Tmax = user_specs{15,2};

%fixed parameter inputs
dt   = user_specs{19,2};
Vs   = user_specs{20,2};
Vctr = user_specs{21,2};
dVctr= user_specs{21,6};
Vctr_min = user_specs{22,2};
Vctr_max = user_specs{23,2};
Lp   = user_specs{24,2};
Ln   = user_specs{25,2};
R    = user_specs{26,2};
RL   = user_specs{30,2}; %new fixed parameter added 01-02-18

%variable parameters
Wp  = user_specs{27,2}; dvar(1) = user_specs{27,6};
Wn  = user_specs{28,2}; dvar(2) = user_specs{28,6};
Wnb = user_specs{29,2}; dvar(3) = user_specs{29,6};

fprintf(['...specs extracted and stored in workspace.\n']);

Vctr_array=[Vctr_min:dVctr:Vctr_max];

nvars = 3; %number of variable parameters
nsteps = 6; %number of steps along a variable parameter axis for seed grid generation
temp=[200,2000]; %variable parameter bounds
dv=50; %step size for all variable parameters
vbnds = [temp;temp;temp]; %[min,max] variable bounds

%evaluation bounds for validity of simulation results
SLB = [0.2,0.9]; %[min,max] state level bounds (V)
DCB = [0.35,0.65]; %[min,max] duty cycle bounds


%SWITCHES=================================================================%
plotting = 1; %option to generate plots throughout and/or at end of pipeline (default=0)
savefigs = 1; %option to automatically save generated figures
savedata = 1; %option to save all data after complete pipeline execution (default=0)
%switch array for database seed generator
switches=[plotting,savefigs,savedata];
interpolate = 1; %option to interpolate time series extracted from LTspice (default=1)

%METRICS==================================================================%
% Save user data
metrics{1} = FT; %target nominal frequency (actual metric #1)
metrics{2} = SLB;
metrics{3} = DCB;
metrics{4} = [eps,tol,nit];
metrics{5} = nvars;
metrics{6} = vbnds;
metrics{7} = dvar;
metrics{8} = DF; %target tuning range (actual metric #2)
metrics{9} = sheet; %circuit type ('1'=VCO9,'2'=PLL1)
save(['metrics.mat'],'metrics');

%INPUTS===================================================================%

% SCHEMATICS (TOP LEVEL BLOCK AND SUBCIRCUITS)
iter = 0; %initialize iteration index
%preparation of circuit parameter cell arrays (labels and values)
comps = {'Vs','Vctr','Tmax','Lp','Ln','R','Wn','Wp','Wnb','RL'};
prefixes = {'','','n','n','n','k','n','n','n','k'};

%top-level
vals{1} = Vs;
vals{2} = Vctr;
vals{3} = Tmax;
%subcircuit constants
vals{4} = Lp;
vals{5} = Ln;
vals{6} = R;
%subcircuit variables
vals{7} = Wn;
vals{8} = Wp;
vals{9} = Wnb;
%additional constants
vals{10} = RL; %new fixed parameter added 01-02-19

%define input cell array for schematic edit/data extraction
inputs{1}=folder;
inputs{2}=schem;
inputs{3}=comps;
inputs{4}=prefixes;
inputs{5}=vals;
inputs{6}=iter;
inputs{7}=probe;
inputs{8}=dt/pico; %MUST CONVERT TIME INCREMENT FROM (ps)->(s)!!!
inputs{9}=interpolate;
inputs{10}=exe_path;
inputs{11}=1; %dummy index for tuning range circuits
inputs{12}=Vctr_array; %control voltage array (for computing tuning range)
inputs{13}=sheet; %circuit type ('1'=VCO9,'2'=PLL1)
inputs{14}=filename; %LITE header Excel spreadsheet

%=========================================================================%

if savedata==1
    save(['usermain.mat']);
end


%must check whether database file exists or not
DB_exist_check = exist(['database_',schem,'.mat'],'file');
MG_exist_check = exist(['metric_grid_',schem,'.mat'],'file');
VA_exist_check = exist(['var_arrays_',schem,'.mat'],'file');

if DB_exist_check~=2 %if no database is found in current folder
    error(['Error! Database file not in directory!']);
end

% if DB_exist_check~=2 %if no database is found in current folder
%     disp(['Database not found! Look for metric grid for database seeding...']);
%     if MG_exist_check==2 && VA_exist_check==2 %no database found but a metric grid found
%         disp(['Metric grid found, proceeding to generate an initial database...']);
%         %map valid grid into a rudimentary matrix database
%         metric_grid=importdata(['metric_grid_',schem,'.mat']);
%         var_arrays=importdata(['var_arrays_',schem,'.mat']);
%         [database]=database_gen(metric_grid,var_arrays,schem);
%     else %no database OR metric grid found
%         disp(['No metric grid found! Proceeding to construct metric grid for database seeding...']);
%         nsteps=input(['Choose number of steps along each variable axis for database initialization N = ']);
%         metrics{9} = nsteps;        
%         %generate grid of valid metrics
%         if ctype==1 %VCO9
%             [metric_grid,var_arrays]=grid_gen1(switches,inputs,metrics,nsteps);
%         elseif ctype==2 %DVCO3
%             [metric_grid,var_arrays]=grid_gen2(switches,inputs,metrics,nsteps);
%         elseif ctype==3 %DVCO4
%             [metric_grid,var_arrays]=grid_gen3(switches,inputs,metrics,nsteps);
%         end
%         %map valid grid into a rudimentary matrix database
%         [database]=database_gen(metric_grid,var_arrays,schem);
%     end
% end

% Other metrics that could be additionally considered:
% -Spectral purity (timing jitter, phase noise)
% -Power consumed
% -Load pulling
% -VCO sensitivity

% Priority weighting array for different metrics will also be incorporated 
% into a future version.

% Initiate optimization pipeline
pipeline(switches,metrics,inputs);

%load all generated data files
% load('var_arrays.mat');
% load('metric_grid.mat');
% load('seeddata.mat');
if sheet==1 %solitary VCO optimization
    DB_filename='database_VCO9.mat'; 
elseif sheet==2 %VCO optimization for PLL
    DB_filename='database_PLL1.mat';
end
load(DB_filename);
load('metrics.mat');
load('pipeline_data.mat');

%close any/all LTspice instances running in background
fclose('all');

