#!/bin/bash

# custom script for synopsys-design-compiler
undefined

