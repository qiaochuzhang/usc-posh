# Development

## Netlist Parser Dependency

```bash
git clone

cd netlist-parser

make
```

Rerun `make` command when the grammar `.g4` files are changed.


## POSH Code

```bash
git clone

cd posh

pip install -r requirements-dev.txt
```
