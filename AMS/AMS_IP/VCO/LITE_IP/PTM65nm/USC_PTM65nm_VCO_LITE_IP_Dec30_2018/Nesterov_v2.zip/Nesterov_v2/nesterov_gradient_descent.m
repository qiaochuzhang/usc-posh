function [in_seed,Nest_switch]=nesterov_gradient_descent(inputs,specs,in_param,param_bounds,d_param,tol,nit)
% parambounds is the parameter array bounds for search space
% schem is the input schem cell array
%Set initial conditions
Nest_switch=0;
Lmin=0; %no local minimum found before search (by definition)
t = 1;
% tol = 9; %error tolerance (%)
a_0 = 1; 
w_0=in_param; %initial starting parameter

z=(2*rand(1,3)-1).*(param_bounds) + in_param; %random point in neighborhood for Lipschitz constant
%call edit_extract_2 to get frequenct at w_0

%update input cell for editing/extraction
% vals{1} = inputs{5}{1};vals{2} = inputs{5}{2};vals{3} = inputs{5}{3};
% vals{4} = inputs{5}{4};vals{5} = inputs{5}{5};vals{6} = inputs{5}{6};
vals=inputs{5}; %extract and edit values
vals{7}=in_param(1); %Wn
vals{8}=in_param(2); %Wp
vals{9}=in_param(3); %Wn,b
inputs{5}=vals; %update inputs
%%%%%%%%% JAS-S %%%%%%%%%%%%
[f_0,Df_0,~]=metric_extract(inputs);
%%%%%%%%% JAS-E%%%%%%%%%%%

%update input cell for editing/extraction
% vals{1} = inputs{5}{1};vals{2} = inputs{5}{2};vals{3} = inputs{5}{3};
% vals{4} = inputs{5}{4};vals{5} = inputs{5}{5};vals{6} = inputs{5}{6};
vals=inputs{5}; %extract and edit values
vals{7} = z(1); %Wn
vals{8} = z(2); %Wp
vals{9} = z(3); %Wn,b
inputs{5}=vals; %update inputs
%%%%%%%%% JAS-S %%%%%%%%%%
[f_z,Df_z,~]=metric_extract(inputs);
f(1)=f_0;
Df(1)=Df_0;
%%%%%%%%% JAS-E%%%%%%%%%%%

% f_0=f_0(w_0); % frequency at w_0;
%call edit_extract_2 to get frequency at z
% f_z=f_0(z); %frequency at z

%%%%%%%%% JAS-S %%%%%%%%%%%%
f_s=specs(1); %user specified frequency
Df_s=specs(2); %user specified tuning range
%%%%%%%%% JAS-E%%%%%%%%%%%

%%%%%%%%%%%%%%% JAS-S%%%%%%%%%%%%%%%
%l_0= sqrt(((50*(f_0 - f_s)).^2 + (Df_0 - Df_s).^2)./(0.1*(f_s)^2 + (0.01*Df_s)^2)); %this is the cost function to be minimized 
%l_0 = ((f_0 - f_s)^2)+((Df_0 - Df_s)*10^(-2))^2;
l_0 = distance(f_0,Df_0,f_s,Df_s);
%l_z = sqrt(((50*(f_z - f_s)).^2 + (Df_z - Df_s).^2)./(0.1*(f_s)^2 + (0.01*Df_s)^2));
%l_z = ((f_z - f_s)^2)+((Df_z - Df_s)*10^(-2))^2;
l_z = distance(f_z,Df_z,f_s,Df_s);


%need to define and call grad function 
disp(['Calculating 1 of 2 pre-descent gradients for all variables...']);
grad_w_0 = grad(inputs,w_0,f_0,f_s,Df_0,Df_s,d_param);% gradient of cost function at w_0
disp(['Calculating 2 of 2 pre-descent gradients for all variables...']);
grad_z = grad(inputs,z,f_z,f_s,Df_z,Df_s,d_param);
epsilon_initial = norm(w_0 - z)./norm(grad_w_0 - grad_z); %initial step size from Lipschitz constraint
%%%%%%%%%%%%%%%%% JAS-E%%%%%%%%%%%%%%

%================= Nesterov Accelerated Gradient Descent =================%

t_switch=0;
epsilon(t)=epsilon_initial;
theta{t}=w_0;
w{t}=w_0;
l(t)=l_0;
a(t)=a_0;

disp(['Nesterov iteration, t = ',num2str(t),', f0(',num2str(t),') = ',...
    num2str(f(t)),' MHz, df0(',num2str(t),') = ',num2str(Df(t)),' MHz (cost L(',num2str(t),') = ',num2str(l(t)),')']);

while(t_switch==0)
    i=0;
    i_switch = 0;
    %%%%%%%%%%%%%%%% JAS-S%%%%%%%%%%%%
    grad_t{t}=grad(inputs,w{t},f(t),f_s,Df(t),Df_s,d_param);
    while(i_switch==0)
        w_temp = w{t} - 2^(-i)*epsilon(t)*grad_t{t};
        %call edit extract on w_temp and get f_temp
    %%%%%%%%%%%%%%%%% JAS-E%%%%%%%%%%%%
    
        %update input cell for editing/extraction
        % vals{1} = inputs{5}{1};vals{2} = inputs{5}{2};vals{3} = inputs{5}{3};
        % vals{4} = inputs{5}{4};vals{5} = inputs{5}{5};vals{6} = inputs{5}{6};
        vals=inputs{5}; %extract and edit values 
        vals{7} = w_temp(1); %Wn
        vals{8} = w_temp(2); %Wp
        vals{9} = w_temp(3); %Wn,b
        inputs{5}=vals; %update inputs
        %%%%%%%%%%%%%%%% JAS-S%%%%%%%%%%%%
        [f_temp,Df_temp,~]=metric_extract(inputs);
        %l_temp = sqrt(((50*(f_temp - f_s)).^2 + (Df_temp - Df_s).^2)./(0.1*(f_s)^2 + (.01*Df_s)^2));
        %l_temp = ((f_temp - f_s)^2)+((Df_temp - Df_s)*10^(-2))^2;
        l_temp = distance(f_temp,Df_temp,f_s,Df_s);
        %%%%%%%%%%%%%%%% JAS-E%%%%%%%%%%%%
        cond = l(t) - l_temp - 2^(-i)*epsilon(t)*0.5*(norm(grad_t{t}).^2);
        if (cond >= -0.05) %the only heuristic at the moment...
            i_switch=1;
        else
            i=i+1;
            disp(['Condition loop iteration, i = ',num2str(i),', condition = ',num2str(cond)]);
        end
    end

    epsilon(t+1) = 2.^(-i)*epsilon(t);
    theta{t+1}= w{t} - epsilon(t+1)*grad_t{t};
    a(t+1)= 0.5*(1+sqrt(4*a(t)^2+2));
    w{t+1}= theta{t+1} + (((a(t)-1)*(theta{t+1}-theta{t}))./(a(t+1)));
    t=t+1;
    
    %call edit_extract to get f_0(t)    
    %update input cell for editing/extraction
    % vals{1} = inputs{5}{1};vals{2} = inputs{5}{2};vals{3} = inputs{5}{3};
    % vals{4} = inputs{5}{4};vals{5} = inputs{5}{5};vals{6} = inputs{5}{6};
    vals=inputs{5}; %extract and edit values 
    vals{7} = w{t}(1); %Wn
    vals{8} = w{t}(2); %Wp
    vals{9} = w{t}(3); %Wn,b
    inputs{5}=vals; %update inputs
     %%%%%%%%%%%%%%%% JAS-S%%%%%%%%%%%%
    [f(t),Df(t),~]=metric_extract(inputs);
    %compute cost function (using relative error for a single metric, for now...)
    %l(t)= sqrt(((50*(f(t) - f_s)).^2 + (Df(t) - Df_s).^2)./(0.1*(f_s)^2 + (0.01*Df_s)^2));
    %l(t) = ((f(t) - f_s)^2)+((Df(t) - Df_s)*10^(-2))^2;
    l(t) = distance(f(t),Df(t),f_s,Df_s);
%     l(t)=100*abs(f(t)-f_s)/f_s; %units of (%) away from target
     %%%%%%%%%%%%%%%% JAS-E%%%%%%%%%%%%

    disp(['Nesterov iteration, t = ',num2str(t),', f0(',num2str(t),') = ',...
    num2str(f(t)),' MHz, df0(',num2str(t),')=',num2str(Df(t)),' MHz (cost L(',num2str(t),') = ',num2str(l(t)),')']);

    if vals{8}/vals{7}<0.8 || min([vals{7},vals{8},vals{9}])<65
        Nest_switch=1;
        t_switch=1;
    end

    %compute local minimum measure (to test convergence to incorrect minimum)
    if t>nit
        errcon=mean(abs(diff(l((t-nit):t))));
        if errcon<1 && l(t)>tol
            Lmin=1;
            t_switch=1; %break out of while loop
        end
    end
    
    if l(t)<=tol
        t_switch=1; %break out of while loop
    end

end

    
if Nest_switch==0 %good transistor sizes
    if Lmin==1
        disp(['Objective unreachable within error tolerance bounds (tolerance = ',...
            num2str(tol),'; cost = ',num2str(l(t)),'%)']);
        Nest_switch=1;
    elseif Lmin==0
        disp(['Convergence to a local minimum detected.']);        
    end    
end

%export latest array
in_seed=round(w{t}); %extract integer transistor widths

end
 
