function [f0]=freq_extract(inputs,index)

inputs{5}{2}=inputs{12}(index); %extract corresponding control voltage
inputs{11}=index; %loop increment value
[raw_data,~]=edit_extract_index(inputs);
f0=raw_data.f0; %store output signal frequency in array

%delete generate files
folder=inputs{1}; schem=inputs{2};
% delete([folder,'/',schem,'_edit_',num2str(index),'.asc']);
delete([folder,'/',schem,'_edit_',num2str(index),'.log']);
delete([folder,'/',schem,'_edit_',num2str(index),'.net']);
% delete([folder,'/',schem,'_edit_',num2str(index),'.raw']);

end
