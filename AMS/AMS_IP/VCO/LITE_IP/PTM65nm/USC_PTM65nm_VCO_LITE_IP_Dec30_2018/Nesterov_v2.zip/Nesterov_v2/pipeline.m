function pipeline(switches,metrics,inputs)
%main pipeline function (executes all auxiliary functions)
% clear all;clc;clf;close all;
TPT_tic=tic; %total pipeline time
appendDB=0; %switch to append KGD to database (default must be 0 to avoid copies)
disp('Taking in user specs and preparing circuit arrays...');

%{
load(['usermain.mat']);
%}

%extract target metrics and tolerances
FT    = metrics{1}; %target frequency (MHz)
SLB   = metrics{2}; %state level bounds (V)
DCB   = metrics{3}; %duty cycle bounds
eps   = metrics{4}(1); %percent distance of target frequency to search in database (%)
tol   = metrics{4}(2); %percent tolerance for gradient/steepest descent (%)
nit   = metrics{4}(3); %number of iterations to scan for convergence to incorrect minimum
nvars = metrics{5}; %number of variables
vbnds = metrics{6}; %variable parameter bounds
dvar  = metrics{7}; %variable step size for gradient descent
DF    = metrics{8}; %target tuning range (MHz)

%define input cell array for schematic edit/data extraction
folder      = inputs{1};
schem       = inputs{2};
comps       = inputs{3};
prefixes    = inputs{4};
vals        = inputs{5};
iter        = inputs{6};
probe       = inputs{7};
dt          = inputs{8}; %already in units of (s)
interpolate = inputs{9};
exe_path    = inputs{10};
index       = inputs{11};
Vctr_array  = inputs{12};
sheet       = inputs{13}; %circuit type ('1'=VCO9,'2'=PLL1)
filename    = inputs{14}; %LITE header Excel spreadsheet

% %PLL precalculation function
% if sheet==2    
%     [DFVCOTmin,DFVCOTmax,Rmin,Cmin,Rmax,Cmax,zeta_out]=pll_opt(FT,DF);
%     disp(['Damping ratio zeta = ',num2str(zeta_out)]);
%     DF=DFVCOTmin; metrics{8}=DF;
% end

%print summary of user-input metrics/parameters to screen
disp([' ']);
disp(['Metric #1: Target nominal frequency f0 = ',num2str(FT),' MHz']);
disp(['Metric #2: Target tuning range Delta_f = ',num2str(DF),' MHz']);
% disp(['          Noise margins: <=',num2str(SLB(1)),' and >=',num2str(SLB(2)),' V']);
% disp(['          Duty cycle bounds: >=',num2str(DCB(1)),' and <=',num2str(DCB(2))]);
disp(['          Distance tolerance of target frequency for database search: ',num2str(eps)]);
disp(['          Local minimum tolerance for gradient descent search: ',num2str(tol)]);
disp(['          Number of Nesterov search iterations before giving up when stuck at a local minimum: ',num2str(nit)]);

savedata = switches(3);
%other switch values (only change for troubleshooting purposes)
pipe_switch = 1; %initiate data fitting & convexification (default=1)
%('1'=begin with database search,'2'=skip to gradient descent,'3'=skip to convex optimization)

%orders of magnitude (using reciprocal convention, which treats prefixes as units)
femto=1e15; pico=1e12; nano=1e9; micro=1e6; milli=1e3; centi=1e2; 
kilo=1e-3; Mega=1e-6; Giga=1e-9; Tera=1e-12; Peta=1e-15;
tol1=1e-4;
disp([' ']);
disp(['================================================================']);
disp(['INITIATING CIRCUIT OPTIMIZATION PIPELINE']);
disp(['================================================================']);
disp(['PHASE ONE: DATABASE SEARCH']);
P1T_tic=tic; %phase 1 timer start

if pipe_switch==1 %search database
    
    %[database search code goes here]
    [candidates] = database_search(metrics);
    NC=size(candidates,1); %(candidates are sorted from least to greatest frequency)
    
    if NC==1 %a solution found in the database!
        disp(['Solution found in database!']);
        
%         if sheet==1 %solitary VCO candidate
%             disp(['Wn | Wp | Wnb | f0 | Delta_f']);
%             fprintf('%f2.2 nm | %f2.2 nm | %f2.2 nm | %f2.2 MHz | %f2.2 MHz ',...
%                 candidates(1,1),candidates(1,2),candidates(1,3),candidates(1,4),candidates(1,end));
%         elseif sheet==2 %PLL VCO candidate
%             disp(['Wn | Wp | Wnb | fc | Delta_f']);
%             fprintf('%f2.2 nm | %f2.2 nm | %f2.2 nm | %f2.2 MHz | %f2.2 MHz ',...
%                 candidates(1,1),candidates(1,2),candidates(1,3),candidates(1,11),candidates(1,end));
%         end
                
        disp([' ']);
        disp(['Good design solution metrics:']);
        if sheet==1 %solitary VCO
            final_f0=candidates(1,4);
            disp(['f0 = ',num2str(final_f0),' MHz']);
%         elseif sheet==2 %VCO for PLL
%             final_f0=candidates(1,11);
%             disp(['fc = ',num2str(final_f0),' MHz']);            
        end        
        final_Delta_f=candidates(1,end);
        disp(['Delta_f = ',num2str(final_Delta_f),' MHz']);
        
        final_vars=[candidates(1,1),candidates(1,2),candidates(1,3)];
        disp(['Wn = ',num2str(final_vars(1)),' nm']);
        disp(['Wp = ',num2str(final_vars(2)),' nm']);
        disp(['Wn,b = ',num2str(final_vars(3)),' um']);
        
        pipe_switch=0; %stop the flow and directly output circuit (do NOT append to database)
        solution=1; %a solution has been found; proceed to output the circuit
    else
        disp(['No solutions in database.']);
        disp(['Top 10 candidates extracted from database; begin local optimization phase...']);
        pipe_switch=2;
    end
    
    P1T=toc(P1T_tic);
    disp([' ']);
    disp(['Phase 1 complete. Time = ',num2str(P1T),' seconds.']);
 
end
    
if pipe_switch==2 %gradient descent search
    disp(['----------------------------------------------------------------']);
    disp(['PHASE TWO: LOCAL SEARCH VIA GRADIENT DESCENT']);
    P2T_tic=tic; %phase 2 timer start    
    
    %STEEPEST/GRADIENT DESCENT CODE GOES HERE=================================%
    
    %{
    %Editing + Data Extraction codes at your disposal (use one or the other in your descent code):
    %Subroutine inputs:
   
    schem - already defined at top of pipeline subroutine (inputs{2})
    specs - target frequency defined at top of pipeline subroutine (metrics{1})
    in_param - an array of variable parameter values found in database (candidates(1,2:4))
    param_bounds - doesn't appear to be used at all in the subroutine codes...unnecessary input(?)
    d_param - differential change for the variable parameter Jacobian (dvar)
    %}
    
    opt_ind=1; %optimization index (for case with 10 candidates)    
    while opt_ind<11    
        %preparing inputs to steepest descent subroutine
        specs = [FT,DF]; %specs is now an array (for multiple metrics)
        in_param = candidates(opt_ind,1:3);
        
        disp([' ']);
        disp(['Parameters for candidate ',num2str(opt_ind),' of 10:']);
        disp(['Wn = ',num2str(in_param(1)),' nm']);
        disp(['Wp = ',num2str(in_param(2)),' nm']);
        disp(['Wn,b = ',num2str(in_param(3)),' nm']);
        disp(['Metrics for candidate ',num2str(opt_ind),' of 10:']);
        if sheet==1
            disp(['f0 = ',num2str(candidates(opt_ind,4)),' MHz']);
%         elseif sheet==2
%             disp(['fc = ',num2str(candidates(opt_ind,11)),' MHz']);
        end
        disp(['Delta_f = ',num2str(candidates(opt_ind,end)),' MHz']);
        disp([' ']);
        
        param_bounds = [75,75,75*7];
        d_param = dvar;
        %initiate steepest descent algorithm
        disp(['Initiate Multi-Objective Nesterov algorithm.']);
    %     [in_seed,UD]=nesterov_gradient_descent(inputs,specs,in_param,param_bounds,d_param,tol,nit);
        [in_seed,Nest_switch]=nesterov_gradient_descent(inputs,specs,in_param,param_bounds,d_param,tol,nit);
        if Nest_switch==1 %no convergence/good design found, move onto next candidate
            opt_ind=opt_ind+1;
        elseif Nest_switch==0 %convergence found!
            opt_ind=11;
        end    
    end
    disp(['Multi-Objective Nesterov algorithm complete.']);
    %=========================================================================%
 
    if Nest_switch==0 %solution found by Nesterov...
    
        %if local min has been found, stop pipeflow and indicate solution has been found
%         disp(['Evaluating constraints (noise margin, etc)...']);    

        %need to plug in final "in_seed" parameter values to extract data for evaluation

        %update input cell for editing/extraction
        vals = inputs{5};
        vals{7} = in_seed(1); %Wn
        vals{8} = in_seed(2); %Wp
        vals{9} = in_seed(3); %Wn,b
        inputs{5} = vals;%vals (update inputs)

        [final_f0,final_Delta_f,final_f0_array]=metric_extract(inputs);

        %prepare inputs to evaluation subroutine for verification
        final_vars=in_seed; %(nm,nm,nm)
%         final_err=100*abs(final_f0-FT)/FT; %final error (%)
%         final_err=100*((final_f0-FT)^2+(final_Delta_f-DF)^2)/(FT^2+DF^2); %final error (distance) (%)

%         [raw_data,~]=edit_extract_index(inputs);
%         data_in{1} = raw_data.vout; %evaluate local minimum found
%         reqs{1} = SLB;
%         reqs{2} = DCB;
%         %decide whether discovered point is valid
%         [td]=evaluator(data_in,reqs);

%         disp(['Local minimum appears valid; append to database...']);
        disp(['Appending local minimum to database...']);
        appendDB=1; %switch on database append
        pipe_switch=3; %append found good design to database in final phase
        solution=1; %output good design

        P2T=toc(P2T_tic);
        disp([' ']);
        disp(['Phase 2 complete. Time = ',num2str(P2T),' seconds.']);
    
    
    elseif Nest_switch==1 %no solution...
    
        pipe_switch=0; %stop flow
        solution=0; %no solution found
    
    end
    
end

if pipe_switch==3 %display results and append database
    
    disp(['----------------------------------------------------------------']);
    disp(['FINAL PHASE: APPEND SOLUTION TO DATABASE AND/OR OUTPUT DESIGN']);
    P3T_tic=tic; %phase 3 timer start

%     relerr=100*abs(candidates(1,1)-FT)/FT;
    
    disp([' ']);
    disp(['Good design solution metric:']);
    if sheet==1; stemp='f0 = '; 
%     elseif sheet==2; stemp='fc = '; 
    end
    disp([stemp,num2str(final_f0),' MHz']);
    disp(['Delta_f = ',num2str(final_Delta_f),' MHz']);
%     disp(['Relative error = ',num2str(final_err),'%']);
    disp(['Good VCO design solution parameters:']);
    %will want to automate this using the header in the future!!
    disp(['Wn = ',num2str(final_vars(1)),' nm']);
    disp(['Wp = ',num2str(final_vars(2)),' nm']);
    disp(['Wn,b = ',num2str(final_vars(3)),' nm']);

    disp([' ']);
    if appendDB==1
        disp(['Updating database...']);
        if sheet==1
            DB_filename='database_VCO9.mat';
%         elseif sheet==2
%             DB_filename='database_PLL1.mat';
        end
        database=importdata(DB_filename); %load corresponding database
        database=[database;[final_vars,final_f0_array,final_Delta_f]];
        save(DB_filename,'database','-v7.3');
    end
    fclose('all'); %close all running instances of LTspice

    P3T=toc(P3T_tic);
    disp([' ']);
    disp(['Phase 3 complete. Time = ',num2str(P3T),' seconds.']);
    
end

fclose('all'); %close all running instances of LTspice

disp(['----------------------------------------------------------------']);
TPT=toc(TPT_tic);
disp(['The total pipeline time (TPT) = ',num2str(TPT),' seconds.']);
disp(' ');

%for troubleshooting purposes (comment out when not in use)
% solution=1;

if solution==1
    disp(['Output found good design...']);
    
    %use winning candidate's parameters (again, will automate this in the
    %future...)
    
    %update input cell for editing/extraction
    vals{1} = inputs{5}{1};
    vals{2} = inputs{5}{2};
    vals{3} = inputs{5}{3};
    vals{4} = inputs{5}{4};
    vals{5} = inputs{5}{5};
    vals{6} = inputs{5}{6}; 
    vals{7} = final_vars(1); %Wn
    vals{8} = final_vars(2); %Wp
    vals{9} = final_vars(3); %Wn,b
    vals{10}= inputs{5}{10}; %RL (new fixed-parameter added 01-02-19)
    
    %editor inputs
    if sheet==1 %solitary VCO
        F_folder   = folder;
        F_schem    = schem;
        F_comps    = comps;
        F_prefixes = prefixes;
        F_vals     = vals;
%     elseif sheet==2
%         [~,~,user_specs]=xlsread(filename,sheet);
%         F_folder = user_specs{2,2};
%         F_schem  = user_specs{3,2};
%         for i=1:14 %total of 14 parameters in top-level LTspice PLL schematic
%             F_comps{i} = user_specs{9+i,1};
%             F_vals{i}  = user_specs{9+i,2};
%             if isnan(user_specs{9+i,3})==1
%                 F_prefixes{i}='';
%             else
%                 F_prefixes{i}=user_specs{9+i,3};
%             end
%         end
%         %replace transistor width values with Nesterov
%         F_vals{7}=final_vars(2); %Wp
%         F_vals{8}=final_vars(1); %Wn
%         F_vals{9}=final_vars(3); %Wnb
%         F_vals{10}=Cmax; %loop-filter cap
%         F_vals{11}=Rmax; %loop-filter resistor
%         F_vals{13}=1.25*final_vars(1); %Wpd=1.25*Wn
    end        
    
    final_inputs{1} = F_folder; %final folder
    final_inputs{2} = F_schem; %final schem
    final_inputs{3} = F_comps; %final comps
    final_inputs{4} = F_prefixes;%final prefixes
    final_inputs{5} = F_vals; %final vals
    final_inputs{6} = iter; %final iteration number
    
    %generate good design schematic (use good design parameters)
    final_schem_gen(final_inputs);
    exe_path=strtrim(exe_path);    
    schem_final=[F_schem,'_final'];
    schemfile=[F_folder,'/',schem_final,'.asc']; %schematic filename
    % netfile=[F_folder,'/',schem_final,'.net']; %corresponding netlist filename
%     rawfile=[F_folder,'/',schem_final,'.raw']; %raw filename generated by LTspice
    
    %execution commands
    % run_schem=['"' exe_path '" -ascii -b -run "' netfile '"'];
    run_schem=['"' exe_path '" -run "' schemfile '"'];
    system(run_schem);

elseif solution==0
    
    disp(['No solution found, ending program :(']);

end

%option to save all data generated in pipeline function
if savedata==1
    save('pipeline_data.mat');
end


end